//
//  ViewController.swift
//  Chaparala_Assignment02
//
//  Created by Chaparala,Shashankaravi on 1/31/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var firstnameTextField: UITextField!
    
    
    @IBOutlet weak var lastnameTextField: UITextField!
    
    
    @IBAction func onClickOfSubmit(_ sender: UIButton) {
        
        let f_name = firstnameTextField.text!
        let l_name = lastnameTextField.text!
        
        labelDetails.text = "details"
        
        fullnameLabel.text = "FullName: \(f_name) \(l_name)"
        
        let f_ini = f_name.first!
        let l_ini = l_name.first!
        
        initialsLabel.text = "Initials: \(f_ini)\(l_ini)"
    }
    
    
    
    @IBAction func onClickOfReset(_ sender: UIButton) {
        
        labelDetails.text = ""
        fullnameLabel.text = ""
        initialsLabel.text = ""
        firstnameTextField.text = ""
        lastnameTextField.text = ""
        
        
        firstnameTextField.becomeFirstResponder() == true
        
    }
    
    
    
    @IBOutlet weak var labelDetails: UILabel!
    
    
    
    @IBOutlet weak var fullnameLabel: UILabel!
    
    
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

